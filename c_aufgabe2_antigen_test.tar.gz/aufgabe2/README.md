# Antigen Schnelltest 

Please make sure that a *./tmp*-directory exists.

## How to run
To run the application, run the following command:
´´´bash
make run
´´´

## How to test
To test the file generation process run the following command:
´´´bash
make run-test
´´´

---

## The test file generator
Use the command 
´´´bash
./test -h
´´´
to see a list of parameters.

**IMPORTANT**
The *-p Path* parameter is required to run the generator.
