void get_buchung(char * buchung);
